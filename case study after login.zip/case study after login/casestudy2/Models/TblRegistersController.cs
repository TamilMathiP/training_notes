﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace casestudy2.Models
{
    public class TblRegistersController : Controller
    {
        private dcEntities5 db = new dcEntities5();

        // GET: TblRegisters
        public ActionResult Index()
        {
            return View(db.TblRegisters.ToList());
        }

        // GET: TblRegisters/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TblRegister tblRegister = db.TblRegisters.Find(id);
            if (tblRegister == null)
            {
                return HttpNotFound();
            }
            return View(tblRegister);
        }

        // GET: TblRegisters/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: TblRegisters/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "UserId,UserName,sex,PhoneNumber,UserAddress,MailId,UserPwd")] TblRegister tblRegister)
        {
            if (ModelState.IsValid)
            {
                db.TblRegisters.Add(tblRegister);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(tblRegister);
        }

        // GET: TblRegisters/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TblRegister tblRegister = db.TblRegisters.Find(id);
            if (tblRegister == null)
            {
                return HttpNotFound();
            }
            return View(tblRegister);
        }

        // POST: TblRegisters/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "UserId,UserName,sex,PhoneNumber,UserAddress,MailId,UserPwd")] TblRegister tblRegister)
        {
            if (ModelState.IsValid)
            {
                db.Entry(tblRegister).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(tblRegister);
        }

        // GET: TblRegisters/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TblRegister tblRegister = db.TblRegisters.Find(id);
            if (tblRegister == null)
            {
                return HttpNotFound();
            }
            return View(tblRegister);
        }

        // POST: TblRegisters/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            TblRegister tblRegister = db.TblRegisters.Find(id);
            db.TblRegisters.Remove(tblRegister);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
