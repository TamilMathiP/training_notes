﻿

using casestudy2.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace casestudy2.Controllers
{

    public class LoginController : Controller
    {


        // GET: customers

        public ActionResult ChangePwd()
        {
            return View();
        }
        [HttpPost]
        public ActionResult ChangePwd(int? id, TblLogin rb)
        {
            dcEntities5 db = new dcEntities5();
            id = Convert.ToInt32(Session["UserId"].ToString().Trim());
            var q = db.TblLogins.Find(id);

            if ((rb.UserPwd == q.UserPwd) && (rb.newpwd == rb.confirmpwd))
            {
                q.UserPwd = rb.newpwd;
                db.SaveChanges();
                return RedirectToAction("login");

            }
            else
            {
                ModelState.AddModelError("Error", "Enter valid Credentials");
                return View();
            }
        }

        [HttpGet, OutputCache(NoStore = true, Duration = 1)]

        public ActionResult Index(int? id)
        {
            if (Session["UserId"] == null)
            {
                return RedirectToAction("login", "Login");
            }​

            dcEntities5 db = new dcEntities5();
            if (Session["UserId"] == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            else
            {
                id = Convert.ToInt32(Session["UserId"].ToString().Trim());
                var result = db.TblRegisters.Where(m => m.UserId == id).FirstOrDefault();
                if (result != null)
                    return View(result);
                else
                    return new HttpStatusCodeResult(HttpStatusCode.NotFound);

            }
        }
         [HttpGet, OutputCache(NoStore = true, Duration = 1)]
        public ActionResult staff()
        {
            if (Session["UserId"] == null)
            {
                return RedirectToAction("login", "Login");
            }​
            return View();
        }





        public ActionResult Login()
        {
            return View();
        }


        [HttpPost]
        public ActionResult Login(TblLogin t)
        {

            dcEntities5 db = new dcEntities5();
            if (true)
            {
                var item = db.TblLogins.Where(p => p.UserId.Equals(t.UserId) && p.UserPwd.Equals(t.UserPwd)).FirstOrDefault();
                try
                {
                    Session["UserId"] = item.UserId;
                    if (item.Ro_le.Trim() == "Staff")
                    {
                        return RedirectToAction("Staff");
                    }
                    else
                    {
                        return RedirectToAction("Index");
                    }
                }
                catch (Exception e)
                {
                    ModelState.AddModelError("Error", "Enter proper details");
                    return View();
                }
            }
            else
                return View(t);
        }
        public ActionResult status()
        {
            if (Session["UserId"] == null)
            {
                return RedirectToAction("login", "Login");
            }

            int UserId = Convert.ToInt32(Session["UserId"].ToString().Trim());
            dcEntities5 db = new dcEntities5();
            var result = db.TblPatientAppointments.Where(m => m.UserId == UserId);
            if (result != null)
                return View(result);
            else
                return new HttpStatusCodeResult(HttpStatusCode.NotFound);

        }

        public ActionResult fpassword()
        {

            return View();
        }

        [HttpPost]
        public ActionResult fpassword(TblRegister cu)
        {
            dcEntities5 db = new dcEntities5();
            var q = db.TblRegisters.Where(m => m.UserId == cu.UserId).FirstOrDefault();

            if(q != null)
            {
                if ((q.UserId == cu.UserId) && (q.MailId == cu.MailId) && (q.PhoneNumber == cu.PhoneNumber))
                {
                    Session["ForPwdid"] = cu.UserId;
                    return RedirectToAction("ResetPassword");

                }

                else
                {
                    ModelState.AddModelError("Error", "Entered details are not valid");
                    return View();
                }

            }
            else
            {
                ModelState.AddModelError("Error", "This LoginId Does not exist");
                return View();
            }
         


            return View();
        }

        public ActionResult passwordchange()
        {



            return View();
        }
        public ActionResult ResetPassword()
        {



            return View();
        }
        [HttpPost]
        public ActionResult ResetPassword(TblLogin rl)
        {
            dcEntities5 db = new dcEntities5();
            int id = Convert.ToInt32(Session["ForPwdid"].ToString().Trim());
            var q = db.TblLogins.Find(id);
            if((rl.newpwd == null) || (rl.confirmpwd == null))
            {
                ModelState.AddModelError("Error", "These fields are mandatory");
                return View();
            }
            else
            {
                if (rl.newpwd == rl.confirmpwd)
                {
                    q.UserPwd = rl.newpwd;
                    db.SaveChanges();
                    return RedirectToAction("passwordchange");


                }
                else
                {
                    ModelState.AddModelError("Error", "Password does not match");
                    return View();
                }


                return View();
            }
           
        }
    }
}

        
        

       
        

     

 
