﻿using casestudy2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace casestudy2.Controllers
{
    public class AppointmentController : Controller
    {
        dcEntities5 db = new dcEntities5();
        public ActionResult NotYetApproved()
        {

            return View();
        }
        public ActionResult Declined()
        {

            return View();
        }
   
        // GET: Appointment
        public ActionResult Reportblood()
        {
            int id = Convert.ToInt32(Session["AId"].ToString());
            var q = db.TblPatientAppointments.Find(id);

            return View(q);
        }
        public ActionResult Reporturine()
        {
            int id = Convert.ToInt32(Session["AId"].ToString());
            var q = db.TblPatientAppointments.Find(id);

            return View(q);
        }
        public ActionResult Reportthyroid()
        {
            int id = Convert.ToInt32(Session["AId"].ToString());
            var q = db.TblPatientAppointments.Find(id);

            return View(q);
        }
        public ActionResult Reporteeg()
        {
            int id = Convert.ToInt32(Session["AId"].ToString());
            var q = db.TblPatientAppointments.Find(id);

            return View(q);
        }
        public ActionResult Reportecg()
        {
            int id = Convert.ToInt32(Session["AId"].ToString());
            var q = db.TblPatientAppointments.Find(id);

            return View(q);
        }
        public ActionResult Reportlipid()
        {
            int id = Convert.ToInt32(Session["AId"].ToString());
            var q = db.TblPatientAppointments.Find(id);

            return View(q);
        }
        public ActionResult Reportxray()
        {
            int id = Convert.ToInt32(Session["AId"].ToString());
            var q = db.TblPatientAppointments.Find(id);

            return View(q);
        }
        public ActionResult Reportus()
        {
            int id = Convert.ToInt32(Session["AId"].ToString());
            var q = db.TblPatientAppointments.Find(id);

            return View(q);
        }

        public ActionResult Report(int ? id)
        {
        
            var q = db.TblPatientAppointments.Where(m => m.ApplicationId == id).FirstOrDefault();

            if(q.sta_tus.Trim() == "Approve")
            {
                if (q.TestToBeTaken == "Blood Test")
                {
                    Session["AId"] = q.ApplicationId;
                   
                    return RedirectToAction("Reportblood");

                }
                else if (q.TestToBeTaken == "Urine Test")
                {
                    Session["AId"] = q.ApplicationId;
                    return RedirectToAction("Reporturine");
                }
                else if (q.TestToBeTaken == "Thyroid Test")
                {
                    Session["AId"] = q.ApplicationId;
                    return RedirectToAction("Reportthyroid");
                }
                else if (q.TestToBeTaken == "EEG Test")
                {
                    Session["AId"] = q.ApplicationId;
                    return RedirectToAction("Reporteeg");
                }
                else if (q.TestToBeTaken == "ECG Test")
                {
                    Session["AId"] = q.ApplicationId;
                    return RedirectToAction("Reportecg");
                }
                else if (q.TestToBeTaken == "Lipid Test")
                {
                    Session["AId"] = q.ApplicationId;
                    return RedirectToAction("Reportlipid");
                }
                else if (q.TestToBeTaken == "X-Ray Test")
                {
                    Session["AId"] = q.ApplicationId;
                    return RedirectToAction("Reportxray");
                }
                else
                {
                    Session["AId"] = q.ApplicationId;
                    return RedirectToAction("Reportus");
                }
            }
            else if (q.sta_tus.Trim() == "Decline")
            {
               
                return RedirectToAction("Declined");

            }
            else 
            {
                
                return RedirectToAction("NotYetApproved");

            }
          

     
        }
        public ActionResult UserInform()
        {
      
            return View();
        }
        public ActionResult Appointment()
        {
          
            var result = db.TblPatientAppointments;
            return View();
        }
        [HttpGet]
        public ActionResult Index()
        {
           


            dcEntities5 db = new dcEntities5();
            TblPatientAppointment newReg = new TblPatientAppointment();
            return View();
        }
        [HttpPost]
        public ActionResult Index(TblPatientAppointment m)
        {
            dcEntities5 db = new dcEntities5();
            if (ModelState.IsValid)
            {
               int id = Convert.ToInt32(Session["UserId"].ToString());
                //TblPatientAppointment tb = new TblPatientAppointment();
                
                db.TblPatientAppointments.Add(m);
             m.UserId = id;
                m.sta_tus = "pending";
                db.SaveChanges();
                return RedirectToAction("UserInform");
            }
            else
                return View(m);
        }
    }
}

